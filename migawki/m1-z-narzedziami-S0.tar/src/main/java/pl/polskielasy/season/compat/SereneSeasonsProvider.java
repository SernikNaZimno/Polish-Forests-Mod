package pl.polskielasy.season.compat;

import net.minecraft.world.level.Level;
import pl.polskielasy.season.SeasonProvider;
import pl.polskielasy.season.SubSeason;
import sereneseasons.api.season.ISeasonState;
import sereneseasons.api.season.SeasonHelper;

/**
 * Most do Serene Seasons. Ładowany refleksyjnie przez {@link pl.polskielasy.season.Seasons}
 * wyłącznie wtedy, gdy mod "sereneseasons" jest obecny.
 */
public final class SereneSeasonsProvider implements SeasonProvider {
	@Override
	public String name() {
		return "Serene Seasons";
	}

	@Override
	public SubSeason subSeason(Level level) {
		return SubSeason.byOrdinal(SeasonHelper.getSeasonState(level).getSubSeason().ordinal());
	}

	@Override
	public double yearProgress(Level level) {
		ISeasonState state = SeasonHelper.getSeasonState(level);
		double sub = state.getSubSeason().ordinal() + Math.clamp(state.getSubSeasonProgress(), 0.0f, 1.0f);
		return Math.min(sub / 12.0, Math.nextDown(1.0));
	}
}
