package pl.polskielasy.worldgen.chunk;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

class PolskaDimensionTest {
	@Test
	void lowlandsAndUplandsAreExactlyOneToOne() {
		for (int m = -120; m <= 880; m++) {
			assertEquals(m, PolskaDimension.blocksForMeters(m), 0.0);
			assertEquals(PolskaDimension.SEA_LEVEL_Y + m - 1, PolskaDimension.topBlockY(m));
		}
	}

	@Test
	void rysyFitUnderBuildLimitWithHeadroom() {
		int rysy = PolskaDimension.topBlockY(2_499);
		assertTrue(rysy >= 1_990 && rysy <= 2_001, "Rysy na Y " + rysy);
		assertTrue(PolskaDimension.maxY() - rysy >= 25, "za mało miejsca nad Rysami");
		assertEquals(2_031, PolskaDimension.maxY());
	}

	@Test
	void mappingIsContinuousAndIncreasing() {
		double prev = PolskaDimension.blocksForMeters(0);
		for (double m = 0.05; m <= 2_700; m += 0.05) {
			double b = PolskaDimension.blocksForMeters(m);
			assertTrue(b > prev, "nie rośnie przy " + m);
			assertTrue(b - prev < 0.051, "skok przy " + m);
			prev = b;
		}
	}

	@Test
	void inverseMatches() {
		for (double m = 0; m <= 2_600; m += 7.3) {
			assertEquals(m, PolskaDimension.metersForBlocks(PolskaDimension.blocksForMeters(m)), 1e-6);
		}
		assertEquals(100.0, PolskaDimension.metersAboveSea(PolskaDimension.topBlockY(100)), 1e-9);
	}

	@Test
	void gameplayScaleFitsItsDimensionAndIsMonotonic() {
		VerticalScale v = VerticalScale.GAMEPLAY;
		int rysy = v.topBlockY(2_499);
		assertTrue(rysy > 600 && rysy < v.maxY() - 40, "Rysy na Y " + rysy);
		assertTrue(v.topBlockY(1_725) > 480 && v.topBlockY(1_725) < 560, "Babia Góra na Y " + v.topBlockY(1_725));
		assertTrue(v.topBlockY(130) > 120 && v.topBlockY(130) < 145, "nizina na Y " + v.topBlockY(130));
		double prev = v.blocksForMeters(-50);
		for (double m = -49.95; m <= 2_700; m += 0.05) {
			double b = v.blocksForMeters(m);
			assertTrue(b > prev, "nie rośnie przy " + m);
			prev = b;
		}
		for (double m = -40; m <= 2_600; m += 3.7) {
			assertEquals(m, v.metersForBlocks(v.blocksForMeters(m)), 1e-6);
		}
		assertEquals(0, v.blocksForMeters(0), 0.0);
	}
}
