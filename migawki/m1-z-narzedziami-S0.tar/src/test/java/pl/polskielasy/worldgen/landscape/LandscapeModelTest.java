package pl.polskielasy.worldgen.landscape;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.Test;

class LandscapeModelTest {
	private static final long SEED = 20260927L;

	@Test
	void sameSeedGivesSameTerrain() {
		LandscapeModel a = new LandscapeModel(SEED, 1.0);
		LandscapeModel b = new LandscapeModel(SEED, 1.0);
		for (int i = 0; i < 200; i++) {
			double x = i * 7_919.0 - 500_000;
			double z = i * -3_571.0 + 250_000;
			assertEquals(a.sample(x, z), b.sample(x, z));
		}
	}

	@Test
	void mountainsNeverTouchLowlandRegions() {
		LandscapeModel m = new LandscapeModel(SEED, 1.0);
		int beskidy = 0;
		for (long cx = -40; cx <= 40; cx++) {
			for (long cz = -40; cz <= 40; cz++) {
				if (m.regionType(cx, cz) != LandscapeType.BESKIDY) {
					continue;
				}
				beskidy++;
				for (int dx = -1; dx <= 1; dx++) {
					for (int dz = -1; dz <= 1; dz++) {
						assertFalse(m.regionType(cx + dx, cz + dz).isLowland(),
								"Beskidy w komórce " + cx + "," + cz + " graniczą z niziną " + m.regionType(cx + dx, cz + dz) + " w " + (cx + dx) + "," + (cz + dz));
					}
				}
			}
		}
		assertTrue(beskidy > 0, "brak Beskidów w obszarze testowym ok. 5000 × 5000 km");
	}

	@Test
	void allRegionTypesOccur() {
		LandscapeModel m = new LandscapeModel(SEED, 1.0);
		int[] count = new int[LandscapeType.values().length];
		for (long cx = -40; cx <= 40; cx++) {
			for (long cz = -40; cz <= 40; cz++) {
				count[m.regionType(cx, cz).ordinal()]++;
			}
		}
		StringBuilder sb = new StringBuilder();
		for (LandscapeType t : LandscapeType.values()) {
			sb.append(t).append('=').append(count[t.ordinal()]).append(' ');
		}
		System.out.println("Rozkład makroregionów: " + sb);
		for (LandscapeType t : LandscapeType.values()) {
			if (t.isRegionType()) {
				assertTrue(count[t.ordinal()] > 0, "nie wystąpił typ " + t);
			}
		}
	}

	@Test
	void elevationsStayWithinPolishRange() {
		LandscapeModel m = new LandscapeModel(SEED, 1.0);
		for (int i = 0; i < 4_000; i++) {
			double x = (i % 63) * 31_337.0 - 1_000_000;
			double z = (i / 63) * 29_989.0 - 1_000_000;
			ColumnSample s = m.sample(x, z);
			double max = s.type().isLowland() ? 420 : 1_800;
			assertTrue(s.surface() > -120 && s.surface() < max,
					"wysokość poza zakresem: " + s + " w " + x + "," + z);
		}
	}

	/**
	 * Woda stojąca musi być otoczona lądem wyższym od lustra albo wodą o tym samym poziomie.
	 * Dla rzek dopuszczamy stopień 1 m (znane uproszczenie modelu M1).
	 */
	@Test
	void waterIsAlwaysContained() {
		assertWaterContained(new LandscapeModel(SEED, 1.0));
	}

	@Test
	void waterIsAlwaysContainedAtGameplayScale() {
		assertWaterContained(new LandscapeModel(SEED, LandscapeScale.GAMEPLAY, 1.0));
	}

	@Test
	void gameplayScaleHasSmallRegionsAndAllTypesNearby() {
		LandscapeModel m = new LandscapeModel(SEED, LandscapeScale.GAMEPLAY, 1.0);
		assertEquals(1_400.0, m.regionSize(), 1e-9);
		int[] count = new int[LandscapeType.values().length];
		for (long cx = -60; cx <= 60; cx++) {
			for (long cz = -60; cz <= 60; cz++) {
				count[m.regionType(cx, cz).ordinal()]++;
				if (m.regionType(cx, cz) == LandscapeType.BESKIDY) {
					for (int dx = -1; dx <= 1; dx++) {
						for (int dz = -1; dz <= 1; dz++) {
							assertFalse(m.regionType(cx + dx, cz + dz).isLowland());
						}
					}
				}
			}
		}
		StringBuilder sb = new StringBuilder();
		for (LandscapeType t : LandscapeType.values()) {
			sb.append(t).append('=').append(count[t.ordinal()]).append(' ');
			if (t.isRegionType()) {
				assertTrue(count[t.ordinal()] > 0, "w promieniu ok. 85 km brak typu " + t);
			}
		}
		System.out.println("Rozkład (skala rozgrywki, 170 x 170 km): " + sb);
	}

	private static void assertWaterContained(LandscapeModel m) {
		List<double[]> sites = new ArrayList<>();
		double[] sandr = LandscapePreview.find(m, LandscapeType.SANDR, true);
		double[] moraine = LandscapePreview.find(m, LandscapeType.WYSOCZYZNA_MORENOWA, true);
		double[] river = LandscapePreview.findRiver(m);
		for (double[] p : new double[][] {sandr, moraine, river}) {
			if (p != null) {
				sites.add(p);
			}
		}
		assertFalse(sites.isEmpty());
		int waterColumns = 0;
		int[][] dirs = {{1, 0}, {-1, 0}, {0, 1}, {0, -1}};
		for (double[] site : sites) {
			int n = 700;
			int x0 = (int) site[0] - n / 2;
			int z0 = (int) site[1] - n / 2;
			ColumnSample[][] g = new ColumnSample[n][n];
			java.util.stream.IntStream.range(0, n).parallel().forEach(j -> {
				for (int i = 0; i < n; i++) {
					g[j][i] = m.sample(x0 + i, z0 + j);
				}
			});
			for (int j = 1; j < n - 1; j++) {
				for (int i = 1; i < n - 1; i++) {
					ColumnSample c = g[j][i];
					if (!c.hasWater()) {
						continue;
					}
					waterColumns++;
					for (int[] d : dirs) {
						ColumnSample o = g[j + d[1]][i + d[0]];
						boolean ok;
						if (o.hasWater()) {
							// Między kolumnami koryta dozwolone bystrza i kaskady (woda spada do wody).
							ok = o.waterLevel() == c.waterLevel()
									|| c.waterKind() == WaterKind.RIVER && o.waterKind() == WaterKind.RIVER;
						} else {
							ok = o.surfaceMeters() >= c.waterLevel();
						}
						assertTrue(ok, "woda bez brzegu w " + (x0 + i) + "," + (z0 + j) + ": " + c + " obok " + o);
					}
				}
			}
		}
		assertTrue(waterColumns > 100, "za mało wody w obszarach testowych: " + waterColumns);
	}
}
