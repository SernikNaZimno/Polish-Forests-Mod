package pl.polskielasy.worldgen.landscape;

import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.IntStream;
import org.junit.jupiter.api.Test;

/** Sieć rzeczna, morze i wybrzeże: brzegi wód, poprawność spływu, brak klifów przy źródłach. */
class RiverNetworkTest {
	private static final long SEED = 20260927L;

	@Test
	void waterIsContainedAtCoastStreamsOxbowsAndLakesRealistic() {
		assertSitesContained(new LandscapeModel(SEED, 1.0), 2_000);
	}

	@Test
	void waterIsContainedAtCoastStreamsOxbowsAndLakesGameplay() {
		assertSitesContained(new LandscapeModel(SEED, LandscapeScale.GAMEPLAY, 1.0), 100);
	}

	@Test
	void networkIsAcyclicAndLevelsNeverRiseDownstream() {
		for (LandscapeScale scale : new LandscapeScale[] {LandscapeScale.REALISTIC, LandscapeScale.GAMEPLAY}) {
			LandscapeModel m = new LandscapeModel(SEED, scale, 1.0);
			RiverNetwork net = networkOf(m);
			int checked = 0;
			for (int order = 1; order <= 3; order++) {
				for (long i = -12; i <= 12; i += 3) {
					for (long j = -12; j <= 12; j += 3) {
						RiverNetwork.Node n = net.node(order, i, j);
						for (int step = 0; step < 5_000; step++) {
							RiverNetwork.Link l = net.link(n);
							if (l.kind() != 1) {
								if (l.kind() == 2) {
									assertTrue(net.level(n) >= l.target().levelAt(l.targetT()) - 1e-9,
											"poziom rośnie przy ujściu dopływu");
								}
								break;
							}
							RiverNetwork.Node d = net.node(order, l.di(), l.dj());
							assertTrue(d.route() < n.route(), "spływ pod górę");
							assertTrue(net.level(d) <= net.level(n) + 1e-9,
									"poziom wody rośnie z biegiem cieku w " + n);
							n = d;
							checked++;
							assertTrue(step < 4_999, "cykl w sieci rzecznej od węzła " + n);
						}
					}
				}
			}
			assertTrue(checked > 50, "za mało sprawdzonych odcinków: " + checked);
		}
	}

	/**
	 * Przy źródłach potoków w górach różnica wysokości między sąsiednimi suchymi kolumnami nie może
	 * przekraczać stromego stoku; stary model rzek dawał tu pionowy klif.
	 */
	@Test
	void mountainStreamSourcesHaveNoCliffs() {
		LandscapeModel m = new LandscapeModel(SEED, 1.0);
		RiverNetwork net = networkOf(m);
		double[] site = find(m, s -> s.type() == LandscapeType.BESKIDY, 5_000);
		assertTrue(site != null, "brak Beskidów w obszarze testowym");
		int sources = 0;
		double worst = 0;
		String where = "";
		long gi = (long) Math.floor(site[0] / 1_250);
		long gj = (long) Math.floor(site[1] / 1_250);
		for (long i = gi - 10; i <= gi + 10 && sources < 12; i++) {
			for (long j = gj - 10; j <= gj + 10 && sources < 12; j++) {
				RiverNetwork.Segment s = net.segment(1, i, j);
				if (s == null || !s.source) {
					continue;
				}
				sources++;
				for (double t = 0; t <= 0.5; t += 0.05) {
					double cx = s.px(t);
					double cz = s.pz(t);
					for (int k = -60; k <= 60; k += 3) {
						double tl = Math.hypot(s.dx(t), s.dz(t));
						double x = cx - s.dz(t) / tl * k;
						double z = cz + s.dx(t) / tl * k;
						// Tylko suchy teren: brzeg koryta nad wodą może być stromy.
						ColumnSample c0 = m.sample(x, z);
						ColumnSample c1 = m.sample(x + 1, z);
						ColumnSample c2 = m.sample(x, z + 1);
						if (c0.hasWater() || c1.hasWater() || c2.hasWater()) {
							continue;
						}
						double h0 = c0.surface();
						double step = Math.max(Math.abs(c1.surface() - h0), Math.abs(c2.surface() - h0));
						if (step > worst) {
							worst = step;
							where = Math.round(x) + "," + Math.round(z);
						}
					}
				}
			}
		}
		assertTrue(sources > 0, "brak źródeł potoków w górach");
		assertTrue(worst < 3.0, "klif przy źródle: różnica " + worst + " m na 1 m w " + where);
	}

	static RiverNetwork networkOf(LandscapeModel m) {
		try {
			var f = LandscapeModel.class.getDeclaredField("rivers");
			f.setAccessible(true);
			return (RiverNetwork) f.get(m);
		} catch (ReflectiveOperationException e) {
			throw new AssertionError(e);
		}
	}

	static double[] find(LandscapeModel m, Predicate<ColumnSample> test, double step) {
		for (int r = 0; r < 800; r++) {
			int n = Math.max(12, r * 2);
			for (int k = 0; k < n; k++) {
				double a = k * (2 * Math.PI / n) + r * 0.37;
				double x = Math.cos(a) * r * step;
				double z = Math.sin(a) * r * step;
				if (test.test(m.sample(x, z))) {
					return new double[] {x, z};
				}
			}
		}
		return null;
	}

	private static void assertSitesContained(LandscapeModel m, double step) {
		List<double[]> sites = new ArrayList<>();
		List<String> names = new ArrayList<>();
		add(sites, names, "wybrzeże", find(m, s -> s.waterKind() == WaterKind.SEA && s.type() == LandscapeType.MORZE
				&& s.surface() > -2, step));
		add(sites, names, "zalew", find(m, s -> s.waterKind() == WaterKind.SEA && s.type() == LandscapeType.POBRZEZE,
				step / 4));
		add(sites, names, "potok górski", findStream(m));
		add(sites, names, "starorzecze", find(m, s -> s.waterKind() == WaterKind.OXBOW, step / 4));
		add(sites, names, "rzeka nizinna", find(m, s -> s.waterKind() == WaterKind.RIVER && s.type().isLowland(),
				step / 4));
		System.out.println("Miejsca testowe: " + names);
		assertTrue(names.contains("wybrzeże") && names.contains("potok górski") && names.contains("rzeka nizinna"),
				"nie znaleziono wszystkich rodzajów wód: " + names);
		int[][] dirs = {{1, 0}, {-1, 0}, {0, 1}, {0, -1}};
		for (int q = 0; q < sites.size(); q++) {
			double[] site = sites.get(q);
			int n = 500;
			int x0 = (int) site[0] - n / 2;
			int z0 = (int) site[1] - n / 2;
			ColumnSample[][] g = new ColumnSample[n][n];
			IntStream.range(0, n).parallel().forEach(j -> {
				for (int i = 0; i < n; i++) {
					g[j][i] = m.sample(x0 + i, z0 + j);
				}
			});
			for (int j = 1; j < n - 1; j++) {
				for (int i = 1; i < n - 1; i++) {
					ColumnSample c = g[j][i];
					if (!c.hasWater()) {
						continue;
					}
					for (int[] d : dirs) {
						ColumnSample o = g[j + d[1]][i + d[0]];
						boolean ok;
						if (o.hasWater()) {
							// Między kolumnami koryta dozwolone bystrza i kaskady (woda spada do wody),
							// przy ujściu do jeziora lub morza najwyżej stopień 1 m.
							boolean cascade = c.waterKind() == WaterKind.RIVER && o.waterKind() == WaterKind.RIVER;
							boolean flowing = c.waterKind() == WaterKind.RIVER || o.waterKind() == WaterKind.RIVER;
							ok = o.waterLevel() == c.waterLevel() || cascade
									|| flowing && Math.abs(o.waterLevel() - c.waterLevel()) <= 1;
						} else {
							ok = o.surfaceMeters() >= c.waterLevel();
						}
						assertTrue(ok, names.get(q) + ": woda bez brzegu w " + (x0 + i) + "," + (z0 + j) + ": " + c
								+ " obok " + o);
					}
				}
			}
		}
	}

	/** Potok w górach: punkt na osi koryta cieku rzędu 1 lub 2 w Beskidach. */
	static double[] findStream(LandscapeModel m) {
		RiverNetwork net = networkOf(m);
		double[] site = find(m, s -> s.type() == LandscapeType.BESKIDY, m.scale() == LandscapeScale.REALISTIC ? 5_000 : 200);
		if (site == null) {
			return null;
		}
		for (int order = 1; order <= 2; order++) {
			double a = order == 1 ? 1_250 * m.scale().mountainSpacing() : 5_000 * Math.max(m.scale().meso(), 0.2);
			long gi = (long) Math.floor(site[0] / a);
			long gj = (long) Math.floor(site[1] / a);
			for (long i = gi - 6; i <= gi + 6; i++) {
				for (long j = gj - 6; j <= gj + 6; j++) {
					RiverNetwork.Segment s = net.segment(order, i, j);
					if (s == null) {
						continue;
					}
					for (double t = 0.5; t < 0.95; t += 0.05) {
						double tl = Math.hypot(s.dx(t), s.dz(t));
						double off = s.channelOffset(t);
						double x = s.px(t) - s.dz(t) / tl * off;
						double z = s.pz(t) + s.dx(t) / tl * off;
						ColumnSample c = m.sample(x, z);
						if (c.waterKind() == WaterKind.RIVER && c.type() == LandscapeType.BESKIDY) {
							return new double[] {x, z};
						}
					}
				}
			}
		}
		return null;
	}

	private static void add(List<double[]> sites, List<String> names, String name, double[] p) {
		if (p != null) {
			sites.add(p);
			names.add(name);
		}
	}
}
