package pl.polskielasy.gametest;

import java.util.ArrayList;
import java.util.List;
import net.fabricmc.fabric.api.client.gametest.v1.FabricClientGameTest;
import net.fabricmc.fabric.api.client.gametest.v1.context.ClientGameTestContext;
import net.fabricmc.fabric.api.client.gametest.v1.context.TestSingleplayerContext;
import net.minecraft.client.gui.screens.worldselection.WorldCreationUiState;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.levelgen.presets.WorldPreset;
import pl.polskielasy.PolskieLasy;
import pl.polskielasy.command.PolskaCommands;
import pl.polskielasy.worldgen.chunk.PolskaChunkGenerator;
import pl.polskielasy.worldgen.chunk.PolskaDimension;
import pl.polskielasy.worldgen.landscape.ColumnSample;
import pl.polskielasy.worldgen.landscape.LandscapeModel;
import pl.polskielasy.worldgen.landscape.LandscapeType;
import pl.polskielasy.worldgen.landscape.WaterKind;

/**
 * Test w prawdziwym kliencie: tworzy świat "Polska", mierzy szybkość generacji pełnych chunków
 * i robi zrzuty ekranu w charakterystycznych miejscach wskazanych przez model krajobrazu.
 */
public final class PolskaWorldClientGameTest implements FabricClientGameTest {
	private static final String SEED = "20260927";
	private static final ResourceKey<WorldPreset> PRESET = ResourceKey.create(Registries.WORLD_PRESET,
			PolskieLasy.id("polska"));

	/** Miejsce do obejrzenia: współrzędne, wysokość kamery nad gruntem, kierunek i nachylenie. */
	private record Site(String name, int x, int z, int cameraAboveGround, float yaw, float pitch) {
	}

	@Override
	public void runTest(ClientGameTestContext context) {
		String mode = System.getProperty("polskielasy.gametest", "wszystko");
		if (!mode.equals("widoki") && !mode.equals("wszystko")) {
			return;
		}
		context.runOnClient(mc -> {
			mc.options.renderDistance().set(10);
		});
		try (TestSingleplayerContext sp = context.worldBuilder()
				.adjustSettings(this::selectPolska)
				.create()) {
			sp.getServer().runCommand("gamerule advance_time false");
			sp.getServer().runCommand("gamerule advance_weather false");
			sp.getServer().runCommand("time set 6000");
			sp.getServer().runCommand("weather clear");
			sp.getServer().runCommand("gamemode spectator @a");

			boolean isPolska = sp.getServer().computeOnServer(
					s -> s.overworld().getChunkSource().getGenerator() instanceof PolskaChunkGenerator);
			if (!isPolska) {
				throw new AssertionError("Świat testowy nie używa generatora Polska");
			}
			benchmark(sp);

			List<Site> sites = sp.getServer().computeOnServer(PolskaWorldClientGameTest::findSites);
			String only = System.getProperty("polskielasy.miejsca", "");
			if (!only.isBlank()) {
				List<String> names = List.of(only.split(","));
				sites = sites.stream().filter(site -> names.contains(site.name())).toList();
			}
			for (Site site : sites) {
				int groundY = sp.getServer().computeOnServer(s -> surfaceY(s, site.x(), site.z()));
				int camY = groundY + site.cameraAboveGround();
				PolskieLasy.LOG.info("[test] {}: x={} z={} grunt Y={} ({} m n.p.m.)", site.name(), site.x(), site.z(),
						groundY, PolskaDimension.metersAboveSea(groundY - 1));
				sp.getServer().runCommand(String.format(java.util.Locale.ROOT, "tp @a %d %d %d %.1f %.1f", site.x(), camY, site.z(),
						site.yaw(), site.pitch()));
				for (int step = 0; step < 2; step++) {
					context.waitTicks(20 * 20);
					int loaded = sp.getServer().computeOnServer(s -> s.overworld().getChunkSource().getLoadedChunksCount());
					String client = context.computeOnClient(mc -> mc.level.getChunkSource().gatherStats() + ", fps " + mc.getFps());
					PolskieLasy.LOG.info("[test] {} po {} s: serwer {} chunków; klient: {}", site.name(), (step + 1) * 20,
							loaded, client);
				}
				context.takeScreenshot("polska_" + site.name());
			}
		}
	}

	private void selectPolska(WorldCreationUiState ui) {
		ui.setSeed(SEED);
		ui.setAllowCommands(true);
		for (WorldCreationUiState.WorldTypeEntry entry : ui.getNormalPresetList()) {
			if (entry.preset().is(PRESET)) {
				ui.setWorldType(entry);
				return;
			}
		}
		throw new AssertionError("Brak presetu świata polskielasy:polska na liście typów świata");
	}

	private static int surfaceY(MinecraftServer server, int x, int z) {
		ServerLevel level = server.overworld();
		return level.getChunkSource().getGenerator().getBaseHeight(x, z, Heightmap.Types.WORLD_SURFACE_WG, level,
				level.getChunkSource().randomState());
	}

	/** Generuje synchronicznie obszar 8 × 8 chunków do stanu pełnego i zapisuje czas w logu. */
	private static void benchmark(TestSingleplayerContext sp) {
		sp.getServer().runOnServer(server -> {
			ServerLevel level = server.overworld();
			int ox = 20_000 >> 4;
			int oz = -20_000 >> 4;
			long t0 = System.nanoTime();
			int n = 0;
			for (int cx = 0; cx < 8; cx++) {
				for (int cz = 0; cz < 8; cz++) {
					level.getChunk(ox + cx, oz + cz);
					n++;
				}
			}
			double ms = (System.nanoTime() - t0) / 1e6;
			PolskaChunkGenerator gen = (PolskaChunkGenerator) level.getChunkSource().getGenerator();
			LandscapeModel m = gen.model(level.getSeed());
			long t1 = System.nanoTime();
			double sink = 0;
			for (int x = 0; x < 128; x++) {
				for (int z = 0; z < 128; z++) {
					sink += m.sample(40_000 + x, 40_000 + z).surface();
				}
			}
			double modelMs = (System.nanoTime() - t1) / 1e6;
			PolskieLasy.LOG.info("[test] Model krajobrazu: {} ms na 64 chunki (16 384 kolumny), suma kontrolna {}",
					Math.round(modelMs), Math.round(sink));
			PolskieLasy.LOG.info("[test] Generacja {} pełnych chunków: {} ms ({} ms/chunk)", n, Math.round(ms),
					Math.round(ms / n));
		});
	}

	/** Wybiera miejsca do zrzutów ekranu, przeszukując model krajobrazu na spirali. */
	private static List<Site> findSites(MinecraftServer server) {
		ServerLevel level = server.overworld();
		PolskaChunkGenerator gen = (PolskaChunkGenerator) level.getChunkSource().getGenerator();
		LandscapeModel m = gen.model(level.getSeed());
		List<Site> sites = new ArrayList<>();
		int[] p = spiral(m, s -> s.type() == LandscapeType.SANDR && s.waterKind() == WaterKind.LAKE);
		if (p != null) {
			sites.add(new Site("sandr_jezioro", p[0] + 180, p[1] - 180, 45, 45f, 20f));
		}
		p = spiral(m, s -> s.type() == LandscapeType.WYSOCZYZNA_MORENOWA && s.waterKind() == WaterKind.LAKE);
		if (p != null) {
			sites.add(new Site("morena_oczka", p[0] + 120, p[1] - 120, 35, 45f, 22f));
		}
		p = spiral(m, s -> s.waterKind() == WaterKind.RIVER);
		if (p != null) {
			sites.add(new Site("dolina_rzeki", p[0], p[1], 60, 0f, 25f));
		}
		p = spiral(m, s -> s.type() == LandscapeType.BESKIDY && s.surface() > 1_150);
		if (p != null) {
			sites.add(new Site("beskidy", p[0], p[1], 25, 30f, 12f));
		}
		p = spiral(m, s -> s.type() == LandscapeType.POGORZE);
		if (p != null) {
			sites.add(new Site("pogorze", p[0], p[1], 40, 60f, 15f));
		}
		// Rzeki, doliny i morze.
		p = spiral(m, s -> s.waterKind() == WaterKind.RIVER && s.type().isLowland() && s.surface() - s.waterLevel() < -2.5);
		if (p != null) {
			sites.add(new Site("meandry", p[0], p[1], 70, 20f, 50f));
		}
		addTarget(sites, m, PolskaCommands.Target.STARORZECZE, "starorzecze", 45, 45f);
		addTarget(sites, m, PolskaCommands.Target.ZRODLO, "zrodlo", 30, 20f);
		addCoast(sites, m, PolskaCommands.Target.PLAZA, "plaza", 20);
		addCoast(sites, m, PolskaCommands.Target.WYDMY_NADMORSKIE, "wydmy_nadmorskie", 25);
		addCoast(sites, m, PolskaCommands.Target.KLIF, "klif", 30);
		addTarget(sites, m, PolskaCommands.Target.ZALEW, "zalew", 40, 25f);
		addTarget(sites, m, PolskaCommands.Target.UJSCIE, "ujscie", 60, 35f);
		return sites;
	}

	private static void addTarget(List<Site> sites, LandscapeModel m, PolskaCommands.Target target, String name,
			int above, float pitch) {
		double[] p = PolskaCommands.locate(m, target, 0, 0);
		if (p != null) {
			sites.add(new Site(name, (int) p[0] - 40, (int) p[1] - 40, above, -45f, pitch));
		}
	}

	/** Miejsce na wybrzeżu oglądane z morza, ok. 80 m od brzegu, w stronę lądu. */
	private static void addCoast(List<Site> sites, LandscapeModel m, PolskaCommands.Target target, String name,
			int above) {
		double[] p = PolskaCommands.locate(m, target, 0, 0);
		if (p == null) {
			return;
		}
		// Kierunek ku morzu: spadek odległości od linii brzegowej.
		double e = 50;
		double gx = m.coastDistance(p[0] + e, p[1]) - m.coastDistance(p[0] - e, p[1]);
		double gz = m.coastDistance(p[0], p[1] + e) - m.coastDistance(p[0], p[1] - e);
		double l = Math.max(1e-9, Math.hypot(gx, gz));
		double sx = -gx / l;
		double sz = -gz / l;
		// Yaw w Minecrafcie: 0 = +Z, 90 = -X; kamera patrzy przeciwnie do kierunku ku morzu.
		float yaw = (float) Math.toDegrees(Math.atan2(sx, -sz));
		sites.add(new Site(name, (int) (p[0] + sx * 80), (int) (p[1] + sz * 80), above, yaw, 12f));
	}

	private static int[] spiral(LandscapeModel m, java.util.function.Predicate<ColumnSample> test) {
		for (int r = 0; r < 1_500; r += 2) {
			int samples = Math.max(24, r);
			for (int k = 0; k < samples; k++) {
				double a = k * (2 * Math.PI / samples) + r * 0.37;
				int x = (int) (Math.cos(a) * r * 1_000);
				int z = (int) (Math.sin(a) * r * 1_000);
				if (test.test(m.sample(x, z))) {
					return new int[] {x, z};
				}
			}
		}
		return null;
	}
}
